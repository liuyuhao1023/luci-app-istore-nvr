#!/bin/sh
set -e
rm -rf /tmp/apk_datahash_test
mkdir -p /tmp/apk_datahash_test/control /tmp/apk_datahash_test/data/etc/config
echo 'test=1' > /tmp/apk_datahash_test/data/etc/config/nvr-test

tar -czf /tmp/apk_datahash_test/data.tar.gz -C /tmp/apk_datahash_test/data .
DATA_HASH=$(sha256sum /tmp/apk_datahash_test/data.tar.gz | cut -d' ' -f1)
DATA_SIZE=$(ls -l /tmp/apk_datahash_test/data.tar.gz | awk '{print $5}')

cat << PEOF > /tmp/apk_datahash_test/control/.PKGINFO
pkgname = test-nvr-pkg
pkgver = 1.0.0-r1
pkgdesc = Test NVR package
arch = all
origin = test-nvr-pkg
maintainer = liuyuhao1023
license = MIT
datahash = $DATA_HASH
size = $DATA_SIZE
PEOF

tar -czf /tmp/apk_datahash_test/control.tar.gz -C /tmp/apk_datahash_test/control .
cat /tmp/apk_datahash_test/control.tar.gz /tmp/apk_datahash_test/data.tar.gz > /tmp/apk_datahash_test/test.apk

echo 'Checking test.apk with apk verify:'
apk verify --allow-untrusted /tmp/apk_datahash_test/test.apk
echo 'Testing apk add:'
apk add --allow-untrusted /tmp/apk_datahash_test/test.apk
